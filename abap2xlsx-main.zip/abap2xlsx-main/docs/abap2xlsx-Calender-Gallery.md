The Demo Program ZDEMO_CALENDAR gives you the possibility to create a calendar just be specifying the image locations and descriptions. If you're using this report please share your results here:
 
* [Calendar created since 2012 with abap2xlsx by Gregor Wolf](https://computerservice-wolf.com/privat/)
* [New York Calendar 2012 by Hendrik Neumann](http://dl.dropbox.com/u/3894797/Calendar%20-%20New%20York%20City%20-%202012.pdf)